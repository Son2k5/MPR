
import { Platform, StyleSheet } from 'react-native';
import Weather from './weather';
import List from './List'
import Demo from './demo';

export default function HomeScreen() {
  return (
    <List />
  );
}

